<?php
defined('BASEPATH') OR exit('No direct script access allowed');

    class Dashboard extends CI_Controller {
        public function __construct(){
            parent::__construct();

            $this->load->model('dashboard_model');
            date_default_timezone_set('Asia/Kolkata');
            
        }

        public function index(){
            // echo "nishtha";
            $this->load->view('templates/header');
            $this->load->view('pages/index');
            $this->load->view('templates/footer');
        }

        //This function loads the view page for add category where we can also view the data table
        public function add_category(){
            $data['category'] = $this->dashboard_model->get_category();
            $this->load->view('templates/header');
            $this->load->view('pages/add_category',$data);
            $this->load->view('templates/footer');
        }
        
        //This function loads the form for adding categories
        public function add_new_category(){
            $this->load->view('templates/header');
             $this->load->view('pages/add_new_category');
             $this->load->view('templates/footer');
        }

        //This function inserts the data inside the database for the categories after clicking on the submit
        public function insert_category(){
            // echo "<pre>";
            // print_r($_POST);
            // print_r($_FILES);
            $insert['category_name'] = $this->input->post('category_name');
            // $insert['image'] = $this->input->post('image');
            
            $config['allowed_types'] = 'jpg|png|jpeg';
            
            $_FILES['image']['name'] =str_replace("/","",date('m/d/Y h/i/s', time()).''.rand(10,1000).''.$_FILES['image']['name']);
            $config['filename'] = $_FILES['image']['name'];
            $config['upload_path'] = './assets/uploads/';
            $this->load->library('upload',$config);
            $this->upload->initialize($config);
            if($this->upload->do_upload('image')){
                $insert['image'] = $this->upload->data('file_name');
            }

            // date_default_timezone_set('Asia/Kolkata');
            $insert['created_at'] =date("d-m-Y h:i:sa");


            $this->dashboard_model->insert_category($insert);
            // echo "nishtha";
            redirect('dashboard/add_category');
        }

        public function view_news(){
            $data['news'] = $this->dashboard_model->get_news();
            // echo "<pre>";
            // print_r($data);exit(); 
            $this->load->view('templates/header');
            $this->load->view('pages/view_news',$data);
            $this->load->view('templates/footer');
        }

        public function upload_news(){
            $data['category'] = $this->dashboard_model->get_category();
            // echo "<pre>";
            // print_r($data);exit();
            $this->load->view('templates/header');
            $this->load->view('pages/upload_news',$data);
            $this->load->view('templates/footer');
        }
        public function admin_login(){
            $this->load->view('pages/admin_login');
        }
        public function newstable_view(){
            $this->load->view('templates/header');
            $this->load->view('pages/newstable_view');
            $this->load->view('templates/footer');

        }

        public function upload_new_news(){
            // echo "<pre>";
            // print_r($_FILES);
            // print_r($_POST);exit();
            $config['allowed_types'] = '*';
            //This particular part alters the filename to avoid similar filenames..
            $_FILES['thumbnail_image']['name'] = str_replace("/","",date("d/m/Y_h/i/s").''.$_FILES['thumbnail_image']['name']);
            // echo "<pre>";
            
            $config['filename'] = $_FILES['thumbnail_image']['name'];
            $config['upload_path'] = "./assets/uploads/news/";
            $this->load->library('upload',$config);
            $this->upload->initialize($config);

            if($this->upload->do_upload('thumbnail_image')){
                $insert['thumbnail_image'] = $this->upload->data('file_name');
            }

            $_FILES['body_image']['name'] = str_replace("/","",date("d/m/Y_h/i/s").''.$_FILES['body_image']['name']);
            // echo "<pre>";
            
            $config['filename'] = $_FILES['body_image']['name'];
            $config['upload_path'] = "./assets/uploads/body_image/";
            $this->load->library('upload',$config);
            $this->upload->initialize($config);

            if($this->upload->do_upload('body_image')){
                $insert['body_image'] = $this->upload->data('file_name');
            }




            $insert['title'] = $this->input->post('title');
            $insert['short_description'] = $this->input->post('short_description');
            $insert['description'] = $this->input->post('description');
            $insert['body_description'] = $this->input->post('body_description');
            $insert['lower_description'] = $this->input->post('lower_description');
            $insert['department'] = $this->input->post('category');
            $insert['news_slider_cat'] = $this->input->post('News_slider_type');
            //  echo "<pre>";
            // print_r($_FILES);

            // print_r($_POST);exit();

            $insert['created_at'] = date("Y-m-d h:i:sa");
            $this->dashboard_model->insert_news($insert);

            $data['category'] = $this->dashboard_model->get_category();
            // echo "<pre>";
            // print_r($data);exit();
            $this->load->view('templates/header');
            $this->load->view('pages/upload_news',$data);
            $this->load->view('templates/footer');
            
        }

        public function edit_news($id){
            // echo $id;

            $data['news'] = $this->dashboard_model->get_particular_news($id);
            $data['category'] = $this->dashboard_model->get_category();
            
            // echo "<pre>";
            // print_r($data);
            $this->load->view('templates/header');
            $this->load->view('pages/edit_news',$data);
            $this->load->view('templates/footer');
        }

        public function edit_department($id){
            // echo $id;
            $data['categor']=$this->dashboard_model->specific_department($id);
            // echo "<pre>";
            // print_r($data);
            $this->load->view('templates/header');
            $this->load->view('pages/edit_department',$data);
            $this->load->view('templates/footer');
        }
        public function update_department($id){

            $update['category_name'] = $this->input->post('category_name');
            
            $config['allowed_types'] = 'jpg|png|jpeg|pdf';
            
            $_FILES['image']['name'] =str_replace("/","",date('m/d/Y h/i/s', time()).''.rand(10,1000).''.$_FILES['image']['name']);
            $config['filename'] = $_FILES['image']['name'];
            $config['upload_path'] = './assets/uploads/';
            $this->load->library('upload',$config);
            $this->upload->initialize($config);
            if($this->upload->do_upload('image')){
                $update['image'] = $this->upload->data('file_name');
            }
            
            $update['created_at'] = date("d-m-Y h:i:sa");

            

            $this->dashboard_model->update_department($update,$id);
             
            $data['categor']=$this->dashboard_model->specific_department($id);

            $this->load->view('templates/header');
            $this->load->view('pages/edit_department',$data);
            $this->load->view('templates/footer');

        }



        public function edit_news_data($id){
            $config['allowed_types'] = 'jpg|png|jpeg|pdf';
            
            $_FILES['thumbnail_image']['name'] =str_replace("/","",date('m/d/Y h/i/s', time()).''.rand(10,1000).''.$_FILES['thumbnail_image']['name']);
            $config['filename'] = $_FILES['thumbnail_image']['name'];
            $config['upload_path'] = './assets/uploads/news/';
            $this->load->library('upload',$config);
            $this->upload->initialize($config);
            if($this->upload->do_upload('thumbnail_image')){
                $update['thumbnail_image'] = $this->upload->data('file_name');
            }

            $_FILES['body_image']['name'] = str_replace("/","",date("d/m/Y_h/i/s").''.$_FILES['body_image']['name']);
            // echo "<pre>";
            
            $config['filename'] = $_FILES['body_image']['name'];
            $config['upload_path'] = "./assets/uploads/body_image/";
            $this->load->library('upload',$config);
            $this->upload->initialize($config);

            if($this->upload->do_upload('body_image')){
                $update['body_image'] = $this->upload->data('file_name');
            }


            $update['title'] = $this->input->post('title');
            $update['short_description'] = $this->input->post('short_description');
            $update['description'] = $this->input->post('description');
            $update['body_description'] = $this->input->post('body_description');
            $update['lower_description'] = $this->input->post('lower_description');
            $update['department'] = $this->input->post('category');
            // $update['news_slider_cat'] = $this->input->post('news_slider_cat');
            $update['news_slider_cat'] = $this->input->post('News_slider_type');
            $update['created_at'] = date("Y-m-d h:i:sa");

            // echo "<pre>";
            // print_r($update);

            $this->dashboard_model->update_news($id,$update);

            
            $data['category'] = $this->dashboard_model->get_category();
            $data['news'] = $this->dashboard_model->get_particular_news($id);
            // echo "<pre>";
            // print_r($data);
            $this->load->view('templates/header');
            $this->load->view('pages/edit_news',$data);
            $this->load->view('templates/footer');


        }

        public function particular_news(){
            
        }

        public function delete_news($id){
            $this->load->model('Dashboard_model');
            //get data
            $insert = $this->Dashboard_model->get_particular_news($id);
            $this->Dashboard_model->insert_backup($insert);
            //delete data
            $this->Dashboard_model->delete_news($id);
            redirect(base_url('index.php/dashboard/view_news'));
            
        }
        public function backup_news(){
            $data['news'] = $this->dashboard_model->get_backupNews();
            $this->load->view('templates/header');
            $this->load->view('pages/Backup_news',$data);
            $this->load->view('templates/footer');
           
        }
        public function restore_news($id){
           
            $restore = $this->dashboard_model->get_particular_bkp_news($id);
            $this->dashboard_model->insert_restore_data_OrginalPlace($restore);

            $this->dashboard_model->delete_backup($id);
            // echo "<pre>";
            // print_r($restore);exit();
            redirect(base_url('index.php/dashboard/view_news'));

        }

        //This function loads the view page for add category where we can also view the data table
       

    }

?>