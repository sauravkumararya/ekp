<?php 
    class Dashboard_model extends CI_Model{
        public function __construct(){
            $this->load->database();
        }

        public function get_category(){
            $this->db->select('*');
            $this->db->from('add_category');
            return $this->db->get()->result_array();
        }

        public function get_backupNews(){
            $this->db->select('*');
            $this->db->from('news_backup');
            return $this->db->get()->result_array();
        }


        public function insert_category($insert){
            $this->db->insert('add_category',$insert);
        }

        public function insert_news($insert){
            $this->db->insert('news_upload',$insert);
        }

        public function delete_news($id){
            $this->db->where('id',$id);
            $this->db->delete('news_upload');
        }

        public function get_news(){
            return $this->db->select('*')->from('news_upload')->get()->result_array();
        }

        public function get_particular_news($id){
            $this->db->select('*');
            // $this->db->from()
            $this->db->where('id',$id);
            return $this->db->get('news_upload')->row_array();
        }
        public function get_particular_bkp_news($id){
            $this->db->select('*');
            $this->db->where('id',$id);
            return $this->db->get('news_backup')->row_array();

        }

        public function update_news($id,$update){
            $this->db->where('id',$id);
            $this->db->update('news_upload',$update);
        }

        public function specific_department($id){
            $this->db->select('*');
            $this->db->where('id',$id);
            return $this->db->get('add_category')->row_array();
        }
        public function update_department($update,$id){
            $this->db->where('id',$id);
            $this->db->update('add_category',$update);

        }
        public function insert_backup($insert){
            $this->db->insert('news_backup',$insert);
        }
        public function insert_restore_data_OrginalPlace($insert){
            $this->db->insert('news_upload',$insert);
        
        }

        public function delete_backup($id){
            $this->db->select('*');
            $this->db->where('id',$id);
            $this->db->delete('news_backup');
        }

    } 
?>