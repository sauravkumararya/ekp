


    
		        <!-- Start Switcher -->
       
		<!-- End Switcher -->
        <!-- Loader -->
        <div id="global-loader">
            <img src="https://codeigniter.spruko.com/valex/ltr/public/assets/img/loader.svg" class="loader-img" alt="Loader">
        </div>
        <!-- /Loader -->

        <!-- Page -->
        <div class="page">

            		<!-- main-sidebar -->
		<?php include 'application/views/templates/sidenav.php';?>
			<!-- main-sidebar -->
            <!-- main-content -->
			<div class="main-content app-content">

            				<!-- main-header -->
				<?php include 'application/views/templates/header_view.php';?>
				<!-- /main-header -->
                <!-- container -->
				<div class="container-fluid">
					<form method="post" action="insert_category" enctype="multipart/form-data">
						<div class=" card row" style="padding:25px;display:block;height:600px;margin-top:10px">
							<h2 style="background:#18747a;color:#fff;padding:10px" class="text-center">Add Category</h2>
						
							<div class="col-md-12">
								<label for="">Category Name</label>
								<input type="text" name="category_name" class="form-control">
							</div>
							<div class="col-md-12">
								<label for="">Image Upload</label>
								<input type="file" name="image" class="form-control">
							</div>
							<div class="col-sm-12 text-center" style="padding:15px">
								<button type="submit" class="btn btn-success" style="width:30%;background:#18747a;">Submit</button>
							</div>
						</div>
					</form>
                        
                    
                    	
					
					<!-- breadcrumb -->
					
					<!-- /breadcrumb -->

					<!-- row -->
					
					<!-- row closed -->

				
                </div>
				<!-- Container closed -->

			</div>
			<!-- main-content closed -->

            		<!-- Sidebar-right-->
		    
			<!--/Sidebar-right-->
            
                        <!-- Footer opened -->
            <?php include 'application/views/templates/footer_view.php'; ?>
			<!-- Footer closed -->
        



















