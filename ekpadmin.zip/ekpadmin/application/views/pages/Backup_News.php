



    <body class="main-body app sidebar-mini">
    
		        <!-- Start Switcher -->
        
		<!-- End Switcher -->
        <!-- Loader -->
        <div id="global-loader">
            <img src="https://codeigniter.spruko.com/valex/ltr/public/assets/img/loader.svg" class="loader-img" alt="Loader">
        </div>
        <!-- /Loader -->

        <!-- Page -->
        <div class="page">

            		<!-- main-sidebar -->
		<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
			<?php include 'application/views/templates/sidenav.php';?>
			<!-- main-sidebar -->
            <!-- main-content -->
			<div class="main-content app-content">

            				<!-- main-header -->
				<?php include 'application/views/templates/header_view.php';?>
				<!-- /main-header -->
                <!-- container -->
				<div class="container-fluid">

                    	<div class="card col-sm-12" style="padding:15px;backgroung:#fff;margin-top:10px;">
                        <a href="<?=base_url('index.php/dashboard/view_news')?>" style="margin-left:auto;margin-right:0px;"><button class="btn btn-success" style="width:100%">Restore</button></a>
                        
                    </div>
                    </div>
					<div class="row row-sm">
						<div class="col-xl-12">
							
								<div class="card-body">
								 <div class="card-header pb-0">
									<div class="table-responsive">
										<table class="table text-md-nowrap" style="overflow-y:auto" id="example1">
											<thead>
												<tr>
													<th class="wd-15p border-bottom-0">Id</th>
													<th class="wd-15p border-bottom-0">Thumbnail Image</th>
                                                    <th class="wd-20p border-bottom-0">View Thumbnail Image</th>
													<th class="wd-20p border-bottom-0">Title</th>
													<th class="wd-15p border-bottom-0">Description</th>
                                                    <th class="wd-10p border-bottom-0">Department</th>
													<th class="wd-20p border-bottom-0">News_category</th>
													<th class="wd-20p border-bottom-0">Created At</th>
													
													<th class=" border-bottom-0" style="width:;display:flex;" onclick="a();">Action</th>
												</tr>
											</thead>
											<tbody>
												<?php foreach($news as $del){?>
												<tr>
													<td><?=$del['id']?></td>
													<td><?=$del['thumbnail_image']?></td>
                                                    <td><img style="height:70px;width:70px" src="<?=base_url()?>assets/uploads/news/<?=$del['thumbnail_image']?>" alt="image"></td>
													<td><?=$del['title']?></td>
                                                    <td><?=$del['description']?></td>
                                                    <td><?=$del['department']?></td>
													<td><?=$del['news_slider_cat']?></td>
													<td><?=$del['created_at']?></td>
													<td style="display:flex;">
                                                        
                                                        
                                                        <a href="<?=base_url('index.php/dashboard/restore_news/'.$del['id'])?>" id="restore<?=$del['id']?>"><button  class="btn btn-danger" onclick='a(this.value);' value="<?=$del['id']?>">Restore</button></a>

														<input type="hidden" value="<?=$del['id']?>" id="data<?=$del['id']?>">
														
														
													</td>
												</tr>
												
												<?php } ?>
											</tbody>
										</table>
									</div>
												</div>
								</div>
							</div>
						</div>	
						
					</div>
                    <div class="row row-sm">

					</div> 
									
                </div>
				<!-- Container closed -->

			</div>

            
                        <!-- Footer opened -->
            <div class="main-footer ht-40">
				<div class="container-fluid pd-t-0-f ht-100p">
					<span>Copyright © 2023 NPCI All rights reserved.</span>
				</div>
			</div>
			<!-- Footer closed -->
        </div>

        
<!-- //JAVASCRIPT KA CODE -->
<script>
	// $(function(){
	// 	$("delete").click(function(){
	// 		// alert('manish');
	// 	})
	// })


	function a(sel){
		var text = 'Are you sure you want to Restore ?';
		// alert(sel);
		var value=sel;
		if(confirm(text)==true){
			// alert('true'+sel);
			document.getElementById("restore"+value).href = "http://localhost/ekp/ekpadmin/index.php/dashboard/restore_news/"+value;
		}else{
			document.getElementById("restore"+value).href = "http://localhost/ekp/ekpadmin/index.php/dashboard/Backup_news/";
		}

	}
</script>



















