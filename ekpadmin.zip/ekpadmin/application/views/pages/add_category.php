



    <body class="main-body app sidebar-mini">
    
		        <!-- Start Switcher -->
       
		<!-- End Switcher -->
        <!-- Loader -->
        <div id="global-loader">
            <img src="https://codeigniter.spruko.com/valex/ltr/public/assets/img/loader.svg" class="loader-img" alt="Loader">
        </div>
        <!-- /Loader -->

        <!-- Page -->
        <div class="page">

            		<!-- main-sidebar -->
		<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
			<?php include 'application/views/templates/sidenav.php';?>
			<!-- main-sidebar -->
            <!-- main-content -->
			<div class="main-content app-content">

            				<!-- main-header -->
				<?php include 'application/views/templates/header_view.php';?>
				<!-- /main-header -->
                <!-- container -->
				<div class="container-fluid">

                    	<div class="card col-sm-12" style="padding:15px;backgroung:#fff;margin-top:10px;">
                        <a href="<?=base_url('index.php/dashboard/add_new_category')?>" style="margin-left:auto;margin-right:0px;"><button class="btn btn-success" style="width:100%">Add New Category</button></a>
                        
                    </div>
                    <!-- <div class="card row" style="padding:15px;backgroung:#fff;margin-top:10px;">
                       <div class="col-sm-12">
                        <div class="col-sm-3 col-md-3">a</div>
                        <div class="col-sm-3 col-md-3">b</div>
                        <div class="col-sm-3 col-md-3">c</div>
                        <div class="col-sm-3 col-md-3"> <a href="" style=""><button class="btn btn-success" style="">Add New Category</button></a></div>
                       </div>
                         -->
                    </div>
					<div class="row row-sm">
						<div class="col-xl-12">
							<div class="card">
								<div class="card-header pb-0">
									
								<div class="card-body">
									<div class="table-responsive">
										<table class="table text-md-nowrap" style="overflow-x:auto" id="example1">
											<thead>
												<tr>
													<th class="wd-15p border-bottom-0">Id</th>
													<th class="wd-15p border-bottom-0">Category Name</th>
													<th class="wd-20p border-bottom-0">Image</th>
													<th class="wd-20p border-bottom-0">Image View</th>
													<th class="wd-15p border-bottom-0">Created At</th>
													<th class=" border-bottom-0" style="width:;display:flex;">Action</th>
												</tr>
											</thead>
											<tbody>
												<?php foreach($category as $cat){?>
												<tr>
													<td><?=$cat['id']?></td>
													<td><?=$cat['category_name']?></td>
													<td><?=$cat['image']?></td>
													<td><img style="height:70px;width:70px" src="<?=base_url()?>assets/uploads/<?=$cat['image']?>" alt="image"></td>
													<td><?=$cat['created_at']?></td>
													<td style="width:;display:flex;">
														<a href="<?=base_url('index.php/dashboard/edit_department/'.$cat['id'])?>" class="btn btn-primary">Edit</a>
														<a href="" class="btn btn-success">View</a>
														<a href="" class="btn btn-danger">Delete</a>
													</td>
												</tr>
												
												<?php } ?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
						</div>
						<!--/div-->

						<!--div-->
						
						<!--/div-->

						<!--div-->
						
						<!--/div-->

						<!--div-->
						
					</div>
                    

						<!-- <div class="col-xl-3 col-lg-6 col-sm-6 col-md-6">
							<div class="card text-center">
								<div class="card-body ">
									<div class="feature widget-2 text-center mt-0 mb-3">
										<i class="ti-pie-chart project bg-pink-transparent mx-auto text-pink "></i>
									</div>
									<h6 class="mb-1 text-muted">Marketing Spend</h6>
									<h3 class="font-weight-semibold">$75.045</h3>
								</div>
							</div>
						</div>
						<div class="col-xl-3 col-lg-6 col-sm-6 col-md-6">
							<div class="card text-center">
								<div class="card-body">
									<div class="feature widget-2 text-center mt-0 mb-3">
										<i class="ti-pulse  project bg-teal-transparent mx-auto text-teal "></i>
									</div>
									<h6 class="mb-1 text-muted">Total Profit</h6>
									<h3 class="font-weight-semibold">$46.352</h3>
								</div>
							</div>
						</div>
						<div class="col-xl-3 col-lg-6 col-sm-6 col-md-6">
							<div class="card text-center">
								<div class="card-body ">
									<div class="feature widget-2 text-center mt-0 mb-3">
										<i class="ti-stats-up project bg-success-transparent mx-auto text-success "></i>
									</div>
									<h6 class="mb-1 text-muted">Total Investiment</h6>
									<h3 class="font-weight-semibold">62%</h3>
								</div>
							</div>
						</div>
                        <div class="col-xl-3 col-lg-6 col-sm-6 col-md-6">
							<div class="card text-center">
								<div class="card-body ">
									<div class="feature widget-2 text-center mt-0 mb-3">
										<i class="ti-stats-up project bg-success-transparent mx-auto text-success "></i>
									</div>
									<h6 class="mb-1 text-muted">Total Investiment</h6>
									<h3 class="font-weight-semibold">62%</h3>
								</div>
							</div>
						</div>
                        <div class="col-xl-3 col-lg-6 col-sm-6 col-md-6">
							<div class="card text-center">
								<div class="card-body ">
									<div class="feature widget-2 text-center mt-0 mb-3">
										<i class="ti-stats-up project bg-success-transparent mx-auto text-success "></i>
									</div>
									<h6 class="mb-1 text-muted">Total Investiment</h6>
									<h3 class="font-weight-semibold">62%</h3>
								</div>
							</div>
						</div>
						-->
					
					
					<!-- breadcrumb -->
					
					<!-- /breadcrumb -->

					<!-- row -->
					
					<!-- row closed -->

					<!-- row opened -->
					
					<!-- row closed -->

					<!-- row opened -->
					
					<!-- row close -->

					<!-- row opened -->
					
					<!-- /row -->

				
                </div>
				<!-- Container closed -->

			</div>
			<!-- main-content closed -->

            		<!-- Sidebar-right-->
		
            
                        <!-- Footer opened -->
            <div class="main-footer ht-40">
				<div class="container-fluid pd-t-0-f ht-100p">
					<span>Copyright © 2023 <span>NPCI  All rights reserved.</span>
				</div>
			</div>
			<!-- Footer closed -->
        </div>
		<!-- End Page -->

                    <!-- Back-to-top -->
        



















