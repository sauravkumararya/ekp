
     <script type="text/javascript" src="https://testdost.com/editor/tinymce.min.js"></script>	 
 
					<script type="text/javascript">
					tinymce.init({
					selector: 'textarea',
					images_dataimg_filter: function(img) {
						return img.hasAttribute('internal-blob');
					},
					height: 100,
					theme: 'modern',
					plugins: [
						'advlist autolink lists link image jbimages eqneditor tiny_mce_wiris  charmap print preview hr anchor pagebreak',
						'searchreplace wordcount visualblocks visualchars code fullscreen',
						'insertdatetime media nonbreaking save table contextmenu directionality',
						'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc help'
					],
					toolbar1: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image |  jbimages | eqneditor  | tiny_mce_wiris_formulaEditor | tiny_mce_wiris_formulaEditorChemistry | tiny_mce_wiris_CAS ',
					toolbar2: 'print preview media | forecolor backcolor emoticons | codesample help',
					image_advtab: true,
					templates: [
						{ title: 'Test template 1', content: 'Test 1' },
						{ title: 'Test template 2', content: 'Test 2' }
					],
					content_css: [
						'//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
						'//www.tinymce.com/css/codepen.min.css'
					]
					});
					
	</script>


    <body class="main-body app sidebar-mini">
    
		        <!-- Start Switcher -->
       
		<!-- End Switcher -->
        <!-- Loader -->
        <div id="global-loader">
            <img src="https://codeigniter.spruko.com/valex/ltr/public/assets/img/loader.svg" class="loader-img" alt="Loader">
        </div>
        <!-- /Loader -->

        <!-- Page -->
        <div class="page">

            		<!-- main-sidebar -->
		<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
			<?php include 'application/views/templates/sidenav.php';?>
			<!-- main-sidebar -->
            <!-- main-content -->
			<div class="main-content app-content">

            				<!-- main-header -->
				<?php include 'application/views/templates/header_view.php';?>
				<!-- /main-header -->
                <!-- container -->
				<div class="container-fluid">
                    <form method="post" action="<?=base_url()?>index.php/dashboard/edit_news_data/<?=$news['id']?>" enctype="multipart/form-data">
						<div class=" card row" style="padding:25px;display:block;height:;margin-top:10px">
							<h2 style="background:#18747a;color:#fff;padding:10px" class="text-center">Upload News</h2>
                            <div class="row" style="padding:10px">
                                <div class="col-md-2" style="float:right;padding-top:3px"><label style="float:right;margin-top:3px" for="">Thumbnail Image(Photos)</label></div>
                                <div class="col-md-3"  ><img src="<?=base_url('./assets/uploads/news/'.$news['thumbnail_image'])?>" alt="" style="height:200px;width:300px"></div>
                                <div class="col-md-7"><input type="file" name="thumbnail_image" class="form-control"></div>
                            </div>
							<div class="row" style="padding:10px">
                                <div class="col-md-2" style="float:right;padding-top:3px"><label style="float:right;margin-top:3px" for="">Body Image(Photos)</label></div>
								 <div class="col-md-3"  ><img src="<?=base_url('./assets/uploads/body_image/'.$news['body_image'])?>" alt="" style="height:200px;width:300px"></div>
                                <div class="col-md-7"><input type="file" name="body_image" class="form-control"></div>
                            </div>
                            <div class="row" style="padding:10px">
                                <div class="col-md-2 " style="float:right;padding-top:3px"><label for="" style="float:right;margin-top:3px">Title</label></div>
                                <div class="col-md-10"><input type="text" value="<?=$news['title']?>" name="title" class="form-control"></div>
                            </div>
							<div class="row" style="padding:10px">
                                <div class="col-md-2 " style="float:right;padding-top:3px"><label for="" style="float:right;margin-top:3px">Short Description</label></div>
                                <div class="col-md-10"><input name="short_description" id="" value="<?=$news['short_description']?>" class="form-control" cols="" rows="" maxlength="100"></div>
                            </div>
                            <div class="row" style="padding:10px">
                                <div class="col-md-2 " style="float:right;padding-top:3px"><label style="float:right;margin-top:3px" for="">Description</label></div>
                                <div class="col-md-10"><textarea name="description" class="form-control"><?=$news['description']?></textarea></div>
                            </div>
							<div class="row" style="padding:10px">
                                <div class="col-md-2 " style="float:right;padding-top:3px"><label style="float:right;margin-top:3px" for="">Body Description</label></div>
                                <div class="col-md-10"><textarea name="body_description" class="form-control"><?=$news['body_description']?></textarea></div>
                            </div>
                            <div class="row" style="padding:10px">
                                <div class="col-md-2 " style="float:right;padding-top:3px"><label style="float:right;margin-top:3px" for="">Lower Description</label></div>
                                <div class="col-md-10"><textarea name="lower_description" class="form-control"><?=$news['lower_description']?></textarea></div>
                            </div>
							<div class="row" style="padding:10px">
                                <div class="col-md-2 " style="float:right;padding-top:3px"><label style="float:right;margin-top:3px" for="">Department</label></div>
                                <div class="col-md-5"><input type="text" value="<?= $news['department']?>" readonly class="form-control"></div>
                                <div class="col-md-5">
                                    <select name="category" id="" class="form-control">
                                        <?php foreach($category as $cat){ ?>
                                            <option value="<?=$cat['category_name']?>"><?=strtoupper($cat['category_name'])?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
							 <div class="row" style="padding:10px">
                                <div class="col-md-2 " style="float:right;padding-top:3px"><label for="" style="float:right;margin-top:3px">News slider category</label></div>
                                <div class="col-md-10">
                                <select name="News_slider_type" id="" class="form-control">
                                <option value="newslettter">newslettter</option>
                                <option value="External News Slider">External News Slider</option>
                                <option value="News Slider">News Slider</option>
                                </select>
                                
                            </div>
							<div class="col-sm-12 text-center" style="padding:15px">
								<button type="submit" class="btn btn-success" style="width:30%;background:#18747a;">Submit</button>
							</div>
						</div>
					</form>
                    	
					
					<!-- breadcrumb -->
					
					<!-- /breadcrumb -->

					<!-- row -->
					
					<!-- row closed -->

					<!-- row opened -->
					
					<!-- row closed -->

					<!-- row opened -->
					
					<!-- row close -->

					<!-- row opened -->
					
					<!-- /row -->

				
                </div>
				<!-- Container closed -->

			</div>
			<!-- main-content closed -->

            		<!-- Sidebar-right-->
		
			<!--/Sidebar-right-->
            
                        <!-- Footer opened -->
            <div class="main-footer ht-40">
				<div class="container-fluid pd-t-0-f ht-100p">
					<span>Copyright © 2023 NPCI All rights reserved.</span>
				</div>
			</div>
			<!-- Footer closed -->
        </div>
		<!-- End Page -->

                    <!-- Back-to-top -->
        



















