



    <body class="main-body app sidebar-mini">
    
		        <!-- Start Switcher -->
        
		<!-- End Switcher -->
        <!-- Loader -->
        <div id="global-loader">
            <img src="https://codeigniter.spruko.com/valex/ltr/public/assets/img/loader.svg" class="loader-img" alt="Loader">
        </div>
        <!-- /Loader -->

        <!-- Page -->
        <div class="page">

            		<!-- main-sidebar -->
		<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
			<?php include 'application/views/templates/sidenav.php';?>
			<!-- main-sidebar -->
            <!-- main-content -->
			<div class="main-content app-content">

            				<!-- main-header -->
				<?php include 'application/views/templates/header_view.php';?>
				<!-- /main-header -->
                <!-- container -->
				<div class="container-fluid">

                    	<div class="card col-sm-12" style="padding:15px;backgroung:#fff;margin-top:10px;">
                        <a href="<?=base_url('index.php/dashboard/upload_news')?>" style="margin-left:auto;margin-right:0px;"><button class="btn btn-success" style="width:100%">Upload News</button></a>
                        
                    </div>
                    <!-- <div class="card row" style="padding:15px;backgroung:#fff;margin-top:10px;">
                       <div class="col-sm-12">
                        <div class="col-sm-3 col-md-3">a</div>
                        <div class="col-sm-3 col-md-3">b</div>
                        <div class="col-sm-3 col-md-3">c</div>
                        <div class="col-sm-3 col-md-3"> <a href="" style=""><button class="btn btn-success" style="">Add New Category</button></a></div>
                       </div>
                         -->
                    </div>
					<div class="row row-sm">
						<div class="col-xl-12">
							
								<div class="card-body">
								 <div class="card-header pb-0">
									<div class="table-responsive">
										<table class="table text-md-nowrap" style="overflow-y:auto" id="example1">
											<thead>
												<tr>
													<th class="wd-15p border-bottom-0">Id</th>
													<th class="wd-15p border-bottom-0">Thumbnail Image</th>
                                                    <th class="wd-20p border-bottom-0">View Thumbnail Image</th>
													<th class="wd-20p border-bottom-0">Title</th>
                                                    <th class="wd-10p border-bottom-0">Department</th>
													<th class="wd-20p border-bottom-0">News_category</th>
													<th class="wd-20p border-bottom-0">Created At</th>
													
													<th class=" border-bottom-0" style="width:;display:flex;" onclick="a();">Action</th>
												</tr>
											</thead>
											<tbody>
												<?php foreach($news as $cat){?>
												<tr>
													<td><?=$cat['id']?></td>
													<td><?=$cat['thumbnail_image']?></td>
                                                    <td><img style="height:70px;width:70px" src="<?=base_url()?>assets/uploads/news/<?=$cat['thumbnail_image']?>" alt="image"></td>
													<td><?=$cat['title']?></td>
                                                    <td><?=$cat['department']?></td>
													<td><?=$cat['news_slider_cat']?></td>

													<td><?=$cat['created_at']?></td>
													<td style="display:flex;">
														<a href="<?=base_url('index.php/dashboard/edit_news/'.$cat['id'])?>" ><button  class="btn btn-primary">Edit</button></a>
														<a href="<?=base_url('index.php/dashboard/particular_news/'.$cat['id'])?>" class="btn btn-success">View</a>
														<a href="<?=base_url('index.php/dashboard/delete_news/'.$cat['id'])?>" id="delete<?=$cat['id']?>"><button  class="btn btn-danger" onclick='a(this.value);' value="<?=$cat['id']?>">Delete</button></a>

														<input type="hidden" value="<?=$cat['id']?>" id="data<?=$cat['id']?>">
													</td>
												</tr>
												
												<?php } ?>
											</tbody>
										</table>
									</div>
												</div>
								</div>
							</div>
						</div>
						<!--/div-->

						<!--div-->
						
						<!--/div-->

						<!--div-->
						
						<!--/div-->

						<!--div-->
						
					</div>
                    <div class="row row-sm">
                        

					</div> 
					
					<!-- breadcrumb -->
					
					<!-- /breadcrumb -->

					<!-- row -->
					
					<!-- row closed -->

					<!-- row opened -->
					
					<!-- row closed -->

					<!-- row opened -->
					
					<!-- row close -->

					<!-- row opened -->
					
					<!-- /row -->

				
                </div>
				<!-- Container closed -->

			</div>
			<!-- main-content closed -->

            		<!-- Sidebar-right-->
		
			<!--/Sidebar-right-->
            
                        <!-- Footer opened -->
            <div class="main-footer ht-40">
				<div class="container-fluid pd-t-0-f ht-100p">
					<span>Copyright © 2023 NPCI All rights reserved.</span>
				</div>
			</div>
			<!-- Footer closed -->
        </div>
		<!-- End Page -->

                    <!-- Back-to-top -->
        
<!-- //JAVASCRIPT KA CODE -->
<script>
	// $(function(){
	// 	$("delete").click(function(){
	// 		// alert('manish');
	// 	})
	// })


	function a(sel){
		var text = 'Do you want to delete ?';
		// alert(sel);
		var value=sel;
		if(confirm(text)==true){
			// alert('true'+sel);
			document.getElementById("delete"+value).href = "http://localhost/ekp/ekpadmin/index.php/dashboard/delete_news/"+value;
		}else{
			document.getElementById("delete"+value).href = "http://localhost/ekp/ekpadmin/index.php/dashboard/view_news";
		}

	}
</script>



















