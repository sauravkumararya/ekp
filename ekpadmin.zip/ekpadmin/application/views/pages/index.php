



    <body class="main-body app sidebar-mini">
    
		       
        <!-- Loader -->
        <div id="global-loader">
            <img src="https://codeigniter.spruko.com/valex/ltr/public/assets/img/loader.svg" class="loader-img" alt="Loader">
        </div>
        <!-- /Loader -->

        <!-- Page -->
        <div class="page">

            		<!-- main-sidebar -->
		<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
			<?php include 'application/views/templates/sidenav.php';?>
			<!-- main-sidebar -->
            <!-- main-content -->
			<div class="main-content app-content">

            				<!-- main-header -->
				<?php include 'application/views/templates/header_view.php';?>
				<!-- /main-header -->
                <!-- container -->
				<div class="container-fluid">

                    	
					
					

				
                </div>
				<!-- Container closed -->

			</div>
			<!-- main-content closed -->

            
            
                        <!-- Footer opened -->
            <div class="main-footer ht-40">
				<div class="container-fluid pd-t-0-f ht-100p">
					<span>Copyright © 2023 NPCI All rights reserved.</span>
				</div>
			</div>
			<!-- Footer closed -->
        </div>
		<!-- End Page -->

                    <!-- Back-to-top -->
        



















