            
             
   


    <body class="main-body app sidebar-mini">
  
        <!-- Loader -->
        <div id="global-loader">
            <img src="https://codeigniter.spruko.com/valex/ltr/public/assets/img/loader.svg" class="loader-img" alt="Loader">
        </div>
        <!-- /Loader -->

        <!-- Page -->
        <div class="page">

            		<!-- main-sidebar -->
		<div class="app-sidebar__overlay" data-toggle="sidebar"></div>
			<?php include 'application/views/templates/sidenav.php';?>
			<!-- main-sidebar -->
            <!-- main-content -->
			<div class="main-content app-content">

            				<!-- main-header -->
				<?php include 'application/views/templates/header_view.php';?>
				<!-- /main-header -->
                <!-- container -->
				<div class="container-fluid">
                    <form method="post" action="upload_new_news" enctype="multipart/form-data">
						<div class=" card row" style="padding:25px;display:block;height:;margin-top:10px">
							<h2 style="background:#18747a;color:#fff;padding:10px" class="text-center">Upload News</h2>
                            <div class="row" style="padding:10px">
                                <div class="col-md-2" style="float:right;padding-top:3px"><label style="float:right;margin-top:3px" for="">Thumbnail Image(Photos)</label></div>
                                <div class="col-md-10"><input type="file" name="thumbnail_image" class="form-control"></div>
                            </div>
                            <div class="row" style="padding:10px">
                                <div class="col-md-2" style="float:right;padding-top:3px"><label style="float:right;margin-top:3px" for="">Body Image(Photos)</label></div>
                                <div class="col-md-10"><input type="file" name="body_image" class="form-control"></div>
                            </div>
                            <div class="row" style="padding:10px">
                                <div class="col-md-2 " style="float:right;padding-top:3px"><label for="" style="float:right;margin-top:3px">Title</label></div>
                                <div class="col-md-10"><input type="text" name ="title" class="form-control"></div>
                            </div>
                            <div class="row" style="padding:10px">
                                <div class="col-md-2 " style="float:right;padding-top:3px"><label for="" style="float:right;margin-top:3px">Short Description</label></div>
                                <div class="col-md-10"><input name="short_description" id="" class="form-control" cols="" rows="" maxlength="100"></div>
                            </div>
                            <div class="row" style="padding:10px">
                                <div class="col-md-2 " style="float:right;padding-top:3px"><label style="float:right;margin-top:3px" for="">Descrption</label></div>
                                <div class="col-md-10"><textarea name="description" class="form-control"></textarea></div>
                            </div>
                            <div class="row" style="padding:10px">
                                <div class="col-md-2 " style="float:right;padding-top:3px"><label style="float:right;margin-top:3px" for="">Body Description</label></div>
                                <div class="col-md-10"><textarea name="body_description" class="form-control"></textarea></div>
                            </div>
                            <div class="row" style="padding:10px">
                                <div class="col-md-2 " style="float:right;padding-top:3px"><label style="float:right;margin-top:3px" for="">Lower Description</label></div>
                                <div class="col-md-10"><textarea name="lower_description" class="form-control"></textarea></div>
                            </div>
							<div class="row" style="padding:10px">
                                <div class="col-md-2 " style="float:right;padding-top:3px"><label style="float:right;margin-top:3px" for="">Department</label></div>
                                <div class="col-md-10">
                                    <select name="category" id="" class="form-control">
                                        <?php foreach($category as $cat){ ?>
                                            <option value="<?=$cat['category_name']?>"><?=strtoupper($cat['category_name'])?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="row" style="padding:10px">
                                <div class="col-md-2 " style="float:right;padding-top:3px"><label for="" style="float:right;margin-top:3px">News slider category</label></div>
                                <div class="col-md-10">
                                <select name="News_slider_type" id="" class="form-control">
                                <option value="Newslettter">Newslettter</option>
                                <option value="External News Slider">External News Slider</option>
                                <option value="News Slider">News Slider</option>
                                </select>
                                
                            </div>
                            
							<div class="col-sm-12 text-center" style="padding:15px">
								<button type="submit" onclick="" id="submit" class="btn btn-success" style="width:30%;background:#18747a;">Submit</button>
							</div>
						</div>
					</form>
				
                </div>
				

			</div>
            
                        <!-- Footer opened -->
            <div class="main-footer ht-40">
				<div class="container-fluid pd-t-0-f ht-100p">
					<span>Copyright © 2022 NPCI All rights reserved.</span>
				</div>
			</div>
			<!-- Footer closed -->
        </div>
		
        <!-- //javascript code -->
        



















