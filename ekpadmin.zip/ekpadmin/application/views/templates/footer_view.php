<div class="main-footer ht-40">
				<div class="container-fluid pd-t-0-f ht-100p">
					<span>Copyright © 2023 <a href="#">NPCI. All rights reserved.</span>
				</div>
			</div>