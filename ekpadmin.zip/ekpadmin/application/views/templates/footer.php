<a href="#top" id="back-to-top"><i class="las la-angle-double-up"></i></a>

        <!-- JQuery min js -->
        <script src="<?=base_url()?>/assets/plugins/jquery/jquery.min.js"></script>

        <!-- Bootstrap js -->
        <script src="<?=base_url()?>/assets/plugins/bootstrap/js/popper.min.js"></script>
        <script src="<?=base_url()?>/assets/plugins/bootstrap/js/bootstrap.js"></script>

        <!-- Ionicons js -->
        <script src="<?=base_url()?>/assets/plugins/ionicons/ionicons.js"></script>

        <!-- Moment js -->
        <script src="<?=base_url()?>/assets/plugins/moment/moment.js"></script>

        <!-- P-scroll js -->
        <script src="<?=base_url()?>/assets/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
        <script src="<?=base_url()?>/assets/plugins/perfect-scrollbar/p-scroll.js"></script>

        <!-- Sticky js -->
        <script src="<?=base_url()?>/assets/js/sticky.js"></script>

        <!-- eva-icons js -->
        <script src="<?=base_url()?>/assets/js/eva-icons.min.js"></script>

        <!-- Rating js-->
        <script src="<?=base_url()?>/assets/plugins/rating/jquery.rating-stars.js"></script>
        <script src="<?=base_url()?>/assets/plugins/rating/jquery.barrating.js"></script>

        <!-- Sidebar js -->
        <script src="<?=base_url()?>/assets/plugins/side-menu/sidemenu.js"></script>

        <!-- Right-sidebar js -->
        <script src="<?=base_url()?>/assets/plugins/sidebar/sidebar.js"></script>
        <script src="<?=base_url()?>/assets/plugins/sidebar/sidebar-custom.js"></script>

        
		<!--Internal  Chart.bundle js -->
		<script src="<?=base_url()?>/assets/plugins/chart.js/Chart.bundle.min.js"></script>

		<!--Internal Sparkline js -->
		<script src="<?=base_url()?>/assets/plugins/jquery-sparkline/jquery.sparkline.min.js"></script>

		<!-- Raphael js -->
		<script src="<?=base_url()?>/assets/plugins/raphael/raphael.min.js"></script>

		<!--Internal Apexchart js-->
		<script src="<?=base_url()?>/assets/js/apexcharts.js"></script>

		<!-- Internal Map -->
		<script src="<?=base_url()?>/assets/plugins/jqvmap/jquery.vmap.min.js"></script>
		<script src="<?=base_url()?>/assets/plugins/jqvmap/maps/jquery.vmap.usa.js"></script>

		<!--Internal  index js -->
		<script src="<?=base_url()?>/assets/js/index.js"></script>
		<script src="<?=base_url()?>/assets/js/jquery.vmap.sampledata.js"></script>
		
	
        <!-- Horizontalmenu js-->
        <script src="<?=base_url()?>/assets/plugins/horizontal-menu/horizontal-menu-2/horizontal-menu.js"></script>

        <!-- Internal Data tables -->
		<script src="<?=base_url()?>/assets/plugins/datatable/js/jquery.dataTables.min.js"></script>
		<script src="<?=base_url()?>/assets/plugins/datatable/js/dataTables.dataTables.min.js"></script>
		<script src="<?=base_url()?>/assets/plugins/datatable/js/dataTables.responsive.min.js"></script>
		<script src="<?=base_url()?>/assets/plugins/datatable/js/responsive.dataTables.min.js"></script>
		<script src="<?=base_url()?>/assets/plugins/datatable/js/jquery.dataTables.js"></script>
		<script src="<?=base_url()?>/assets/plugins/datatable/js/dataTables.bootstrap4.js"></script>
		<script src="<?=base_url()?>/assets/plugins/datatable/js/dataTables.buttons.min.js"></script>
		<script src="<?=base_url()?>/assets/plugins/datatable/js/buttons.bootstrap4.min.js"></script>
		<script src="<?=base_url()?>/assets/plugins/datatable/js/jszip.min.js"></script>
		<script src="<?=base_url()?>/assets/plugins/datatable/js/pdfmake.min.js"></script>
		<script src="<?=base_url()?>/assets/plugins/datatable/js/vfs_fonts.js"></script>
		<script src="<?=base_url()?>/assets/plugins/datatable/js/buttons.html5.min.js"></script>
		<script src="<?=base_url()?>/assets/plugins/datatable/js/buttons.print.min.js"></script>
		<script src="<?=base_url()?>/assets/plugins/datatable/js/buttons.colVis.min.js"></script>
		<script src="<?=base_url()?>/assets/plugins/datatable/js/dataTables.responsive.min.js"></script>
		<script src="<?=base_url()?>/assets/plugins/datatable/js/responsive.bootstrap4.min.js"></script>

        <!--Internal  Datatable js -->
		<script src="<?=base_url()?>/assets/js/table-data.js"></script>
        <!-- custom js -->
        <script src="<?=base_url()?>/assets/js/custom.js"></script>

        <!-- Switcher js -->
	<script src="<?=base_url()?>/assets/switcher/js/switcher.js"></script>
        <!-- tinymc editor   -->
         <script type="text/javascript" src="https://testdost.com/editor/tinymce.min.js"></script>	 
 
					<script type="text/javascript">
					tinymce.init({
					selector: 'textarea',
					images_dataimg_filter: function(img) {
						return img.hasAttribute('internal-blob');
					},
					height: 100,
					theme: 'modern',
					plugins: [
						'advlist autolink lists link image jbimages eqneditor tiny_mce_wiris  charmap print preview hr anchor pagebreak',
						'searchreplace wordcount visualblocks visualchars code fullscreen',
						'insertdatetime media nonbreaking save table contextmenu directionality',
						'emoticons template paste textcolor colorpicker textpattern imagetools codesample toc help'
					],
					toolbar1: 'undo redo | insert | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image |  jbimages | eqneditor  | tiny_mce_wiris_formulaEditor | tiny_mce_wiris_formulaEditorChemistry | tiny_mce_wiris_CAS ',
					toolbar2: 'print preview media | forecolor backcolor emoticons | codesample help',
					image_advtab: true,
					templates: [
						{ title: 'Test template 1', content: 'Test 1' },
						{ title: 'Test template 2', content: 'Test 2' }
					],
					content_css: [
						'//fonts.googleapis.com/css?family=Lato:300,300i,400,400i',
						'//www.tinymce.com/css/codepen.min.css'
					]
					});
					
				   </script>

				    <script src="path/to/tinymce.min.js"></script>
					
    </body>

</html>