<!doctype html>
<html lang="en" dir="ltr">
	
<head>

		<meta charset="UTF-8">
		<meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="Description" content="Bootstrap Responsive Admin Web Dashboard HTML5 Template">
		<meta name="Author" content="Spruko Technologies Private Limited">
		<meta name="Keywords" content="dashboard, admin, bootstrap admin template, codeigniter, php, php framework, codeigniter 4, php mvc, php codeigniter, best php framework, codeigniter admin, codeigniter dashboard, admin panel template, bootstrap 4 admin template, bootstrap dashboard template"/>

                <!-- Title -->
        <title> EKP- National payment co-orporation of India </title>

        <!-- Favicon -->
        <link rel="icon" href="<?=base_url('./assets/img/brand/Npci-fav.png')?>" type="image/x-icon"/>

        <!-- Bootstrap css-->
        <link href="<?=base_url()?>/assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet"/>

        <!-- Icons css -->
        <link href="<?=base_url()?>/assets/css/icons.css" rel="stylesheet">

        <!--  Right-sidemenu css -->
        <link href="<?=base_url()?>/assets/plugins/sidebar/sidebar.css" rel="stylesheet">

        <!-- P-scroll bar css-->
        <link href="<?=base_url()?>/assets/plugins/perfect-scrollbar/p-scrollbar.css" rel="stylesheet" />

        <!--  Left-Sidebar css -->
        <link rel="stylesheet" href="<?=base_url()?>/assets/css/sidemenu.css">

        <!-- Style css -->
        <link href="<?=base_url()?>/assets/css/style.css" rel="stylesheet">
        <link href="<?=base_url()?>/assets/css/style-dark.css" rel="stylesheet">

        
		<!-- Maps css -->
		<link href="<?=base_url()?>/assets/plugins/jqvmap/jqvmap.min.css" rel="stylesheet">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
	
        <!-- Skinmodes css -->
        <link href="<?=base_url()?>/assets/css/skin-modes.css" rel="stylesheet" />

        <!-- Animations css -->
        <link href="<?=base_url()?>/assets/css/animate.css" rel="stylesheet">

        <!---Switcher css-->
        <link href="<?=base_url()?>/assets/switcher/css/switcher.css" rel="stylesheet">
        <link href="<?=base_url()?>/assets/switcher/demo.css" rel="stylesheet">

         <script>
        tinymce.init({
            selector: 'textarea', // Specify the selector for your text area or div
            plugins: 'textcolor fontcolor', // Include the necessary plugins
            toolbar: 'forecolor backcolor fontsizeselect', // Add font and color options to the toolbar
        });
    </script>

    <script src="https://kit.fontawesome.com/4282e58786.js" crossorigin="anonymous"></script>
	</head>